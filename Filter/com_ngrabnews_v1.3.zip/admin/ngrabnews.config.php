<?php
define("ADMIN_EMAIL","nhutcorp@gmail.com");
//define("NOHTML","");
define("CRON_LOG",1);
define("SHOWERROR",0);
define("SENDERROR",0);
define("TERMINATEONERROR",0);
define("CRON_DEBUG",0);
define("DEBUGFUNCTION",0);
define("DEBUG",0);
define("PROXY_URL",'');
// If your NGrab News Com is behind a proxy, set the following parameters. Otherwise leave blank
// $proxy_Url : The location of the proxy server
// Format : proxy_name_or_ip:proxy_prot
// E.g. : 192.168.1.102:1010
define("PROXY_USERPWD",'');
// $proxy_UserPwd : Proxy authentication, if required
// Format : username:password
// E.g. : johnd:pass123
define("RUNDETAIL_STEP",4);
define("RUNIMAGE_STEP",10);
define("EXECUTION_TIME",300);
define("IMAGELARGE_SKIP",4);
define("IMAGETHUMB_QUALITY",90);
define("AUTO_EXTRACT_DETAILTEXT",300);

?>