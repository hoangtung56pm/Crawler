<?php
// ensure this file is being included by a parent file
defined( '_JEXEC' ) or die( 'Restricted access' );
//Common Function

	function normalUTF8($cstring='') {
		if ($cstring != '') {
			$mystring ='Ć|C, Ç|C, Č|C, Ď|D, Î|I, Ï|I, Ĺ|L, Ń|N, Ň|N, Ñ|N, Ŕ|R, Ř|R, Š|S, Ś|O, Ť|T, Ž|Z, Ź|Z, ć|c, ç|c, č|c, ď|d, ĺ|l, ń|n, ň|n, ñ|n, š|s, ś|s, ř|r, ŕ|r, ť|t, ů|u, ü|u, ž|z, ź|z, ˙|-, ß|ss, Ą|A, µ|u, Ą|A, µ|u, ą|a, Ą|A, ę|e, Ę|E, ś|s, Ś|S, ż|z, Ż|Z, ź|z, Ź|Z, ć|c, Ć|C, ł|l, Ł|L, ń|n, Ń|N, Å|A, Ä|a, å|a, ä|a, á|a, à|a, ả|a, ã|a, ạ|a, Á|A, À|A, Ả|A, Ã|A, Ạ|a, ấ|a, ầ|a, ẩ|a, ẫ|a, ậ|a, Ấ|A, Ầ|A, Ẩ|A, Ẫ|A, Ậ|A, â|a, Â|A, ắ|a, ằ|a, ẳ|a, ẵ|a, ặ|a, Ắ|A, Ằ|A, Ẳ|A, Ẵ|A, Ặ|a, ă|a, Ă|A, Ö|O, ö|o, ó|o, ò|o, ỏ|o, õ|o, ọ|o, Ó|O, Ò|O, Ỏ|O, Õ|O, Ọ|O, ớ|o, ờ|o, ở|o, ỡ|o, ợ|o, Ớ|O, Ờ|O, Ở|O, Ỡ|O, Ợ|O, ơ|o, Ơ|O, ố|o, ồ|o, ổ|o, ỗ|o, ộ|o, Ố|O, Ồ|O, Ổ|O, Ỗ|O, Ộ|O, ô|o, Ô|O, Ë|E, Ě|E, ę|e, ë|e, ě|e, é|e, è|e, ẻ|e, ẽ|e, ẹ|e, É|E, È|E, Ẻ|E, Ẽ|E, Ẹ|E, ế|e, ề|e, ể|e, ễ|e, ệ|e, Ế|E, Ề|E, Ể|E, Ễ|E, Ệ|E, ê|e, Ê|e, Ů|U, Ü|U, ú|u, ù|u, ủ|u, ũ|u, ụ|u, Ú|U, Ủ|U, Ũ|U, Ù|U, Ụ|U, ứ|u, ừ|u, ử|u, ữ|u, ự|u, Ứ|U, Ừ|U, Ử|U, Ữ|U, Ự|U, ư|u, Ư|U, î|i, ï|i, í|i, ì|i, ỉ|i,ĩ|i, ị|i, Í|I, Ì|I, Ỉ|I, Ĩ|I, Ị|iI, đ|d, Đ|d, ý|y, ỳ|y, ỷ|y, ỹ|y, ỵ|y, Ý|Y, Ỳ|Y, Ỷ|Y, Ỹ|Y, Ỵ|Y';
			$arr1 = explode(', ',$mystring);
			$strcheck =array();
			$strsub =array();
			foreach ($arr1 as $a){
				$b=explode('|',$a);
				$strcheck[] = $b[0];
				$strsub[] = $b[1];
			}
			return str_replace( $strcheck, $strsub, $cstring );
		}
	}

	function clean_url($text) 
	{ 
		$text=strtolower($text); 
		$code_entities_match = array(' ','--','&quot;','!','@','#','$','%','^','&','*','(',')','_','+','{','}','|',':','"','<','>','?','[',']','\\',';',"'",',','.','/','*','+','~','`','=','”','“','`'); 
		$code_entities_replace = array('-','-','','','','','','','','','','','','','','','','','','','','','','','','','','',''); 
		$text = str_replace($code_entities_match, $code_entities_replace, $text); 
		return $text; 
	} 

function html_to_utf8 ($data)
    {
    return preg_replace("/\\&\\#([0-9]{3,10})\\;/e", '_html_to_utf8("\\1")', $data);
    }

function _html_to_utf8 ($data)
    {
    if ($data > 127)
        {
        $i = 5;
        while (($i--) > 0)
            {
            if ($data != ($a = $data % ($p = pow(64, $i))))
                {
                $ret = chr(base_convert(str_pad(str_repeat(1, $i + 1), 8, "0"), 2, 10) + (($data - $a) / $p));
                for ($i; $i > 0; $i--)
                    $ret .= chr(128 + ((($data % pow(64, $i)) - ($data % ($p = pow(64, $i - 1)))) / $p));
                break;
                }
            }
        }
        else
        $ret = "&#$data;";
    return $ret;
    }


	function chars($text_, $charnum){
	$text_ = trim($text_);
	if(($charnum >0) && (utf8_strlen1($text_) > $charnum)) return utf8_substr($text_,0,$charnum)."&hellip;";

	else return $text_;
	}
	
function utf8_strlen1($str) {
  $count = 0;
  for ($i = 0; $i < strlen($str); ++$i) {
    if ((ord($str[$i]) & 0xC0) != 0x80) {
      ++$count;
    }
  }
  return $count;
}

	function cut_string($str,$len,$more){
		if ($str=="" || $str==NULL) return $str;
		if (is_array($str)) return $str;
		$str = trim($str);
		if (utf8_strlen1($str) <= $len) return $str;
		$str = substr($str,0,$len);
		if ($str != "") {
		if (!substr_count($str," ")) {
		if ($more) $str .= " ...";
		return $str;
		}
		while(strlen($str) && ($str[strlen($str)-1] != " ")) {
			$str = substr($str,0,-1);
		}
		$str = substr($str,0,-1);
		if ($more) $str .= " ...";
		}

		return $str;
	}


  function fetchurl ($source, $POSTdata, $UserAgent)
  {
	$proxy_url =PROXY_URL;
	$proxy_userpwd = PROXY_USERPWD;
    $ch = curl_init ($source);
    curl_setopt ($ch, CURLOPT_COOKIEJAR, 'nhutcorp_cookies.txt');
    curl_setopt ($ch, CURLOPT_COOKIEFILE, 'nhutcorp_cookies.txt');
    if ($UserAgent === null)
    {
      $UserAgent = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)';
    }

    curl_setopt ($ch, CURLOPT_USERAGENT, $UserAgent);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt ($ch, CURLOPT_HEADER, 0);
    curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt ($ch, CURLOPT_ENCODING, 'identity;q=1.0, *;q=0');
    if (0 < strlen ($proxy_url))
    {
      curl_setopt ($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
      curl_setopt ($ch, CURLOPT_PROXY, $proxy_url);
      if (0 < strlen ($proxy_userpwd))
      {
        curl_setopt ($ch, CURLOPT_PROXYUSERPWD, $proxy_userpwd);
      }
    }

    if (0 < strlen ($POSTdata))
    {
      curl_setopt ($ch, CURLOPT_POST, 1);
      curl_setopt ($ch, CURLOPT_POSTFIELDS, $POSTdata);
    }

    $yeah = curl_exec ($ch);
    curl_close ($ch);
    return $yeah;
  }

  function debughex ($str)
  {
    echo '<font color="green">';
    $len = strlen ($str);
    $i = 0;
    while ($i < $len)
    {
      echo $str[$i] . ' ' . ord ($str[$i]) . '<br>';
      if (($i + 1) % 10 == 0)
      {
        echo '
';
      }

      ++$i;
    }

    echo '</font><br>
';
  }
  function error ($str)
  {
	$nohtml = NOHTML;
	$terminateonerror = TERMINATEONERROR;
	$showerror = SHOWERROR;
	$senderror = SENDERROR;
	$admin_email = ADMIN_EMAIL;
    if (isset ($nohtml))
    {
      $errmsg = $str;
      if (!is_array ($str))
      {
      }
      else
      {
        $i = 0;
        while ($i < count ($str))
        {
          $errmsg .= $str[$i] . '
';
          ++$i;
        }
      }

      if ($showerror) echo $errmsg . '
';
      if (0 < strlen ($admin_email) && $senderror)
      {
        if (!mail ($admin_email, 'A NGrab News error has occured', $errmsg))
        {
          echo 'Failed to send error email to ' . $admin_email;
        }
      }
    }
    else
    {
      if (!is_array ($str))
      {
        if ($showerror) echo '<font color="red">' . htmlentities ($str) . '</font><br>
';
      }
      else
      {
        $i = 0;
        while ($i < count ($str))
        {
          if ($showerror) echo '<font color="red">' . htmlentities ($str[$i]) . '</font><br>
';
          ++$i;
        }
      }
    }
    if ((isset ($terminateonerror) AND $terminateonerror == '1'))
    {
      exit ();
    }
  }
  function warning ($str)
  {
	$admin_email = ADMIN_EMAIL;
	$nohtml = NOHTML;
	$showerror = SHOWERROR;
	$senderror = SENDERROR;
    if (isset ($nohtml) && $senderror)
    {
      mail ($admin_email, 'A Grab News warning has occured', $str);
      return null;
    }

    if ($showerror) echo '<font color="red">' . htmlentities ($str) . '</font><br>
';
  }
  function debug ($str)
  {
	$debug =DEBUG;
    if ($debug)
    {
      echo '<font color="green">' . htmlentities ($str) . '</font><br>
';
    }

  }
  function debug_function ($dnum,$str,$dcolor)
  {
	$debugfunction = DEBUGFUNCTION;
    if ($debugfunction)
    {
    	$strdot ='';
    	$countdot =substr_count($dnum,'.');
    	if ($countdot >0)
    	{
    		for ($i=0; $i< $countdot; $i++)
    		{
    			$strdot .='_';
    		}
    	}
    	echo '<font color="'.$dcolor.'">' .$strdot .$dnum.'_' . htmlentities ($str) . '</font><br>
';
    }

  }

function time_since($original) {
    $chunks = array(
        array(60 * 60 * 24 * 365 , 'year'),
        array(60 * 60 * 24 * 30 , 'month'),
        array(60 * 60 * 24 * 7, 'week'),
        array(60 * 60 * 24 , 'day'),
        array(60 * 60 , 'hour'),
        array(60 , 'minute'),
    );
    
    $today = time();
    $since = $today - $original;
    for ($i = 0, $j = count($chunks); $i < $j; $i++) {        
        $seconds = $chunks[$i][0];
        $name = $chunks[$i][1];
        if (($count = floor($since / $seconds)) != 0) {
            break;
        }
    }    
    $print = ($count == 1) ? '1 '.$name : "$count {$name}s";   
    if ($i + 1 < $j) {
        $seconds2 = $chunks[$i + 1][0];
        $name2 = $chunks[$i + 1][1];
        if (($count2 = floor(($since - ($seconds * $count)) / $seconds2)) != 0) {
            $print .= ($count2 == 1) ? ', 1 '.$name2 : ", $count2 {$name2}s";
        }
    }
    return $print;
}
function closetags($html) {
$self_closing_tags = array('img', 'br', 'input', 'meta', 'link', 'hr', 'base', 'embed', 'spacer', 'param');
  preg_match_all('#<([a-z]+)(?: .*)?(?<![/|/ ])>#iU', $html, $result);
  $openedtags = $result[1];
  preg_match_all('#</([a-z]+)>#iU', $html, $result);
  $closedtags = $result[1];
  $len_opened = count($openedtags);
  if (count($closedtags) == $len_opened) {
    return $html;
  }
  $openedtags = array_reverse($openedtags);
  for ($i=0; $i < $len_opened; $i++) {
	$pos = strpos($value_my, $value_cmi);
    if (!in_array($openedtags[$i], $closedtags) && !strpos_arr($openedtags[$i],$self_closing_tags)){
      $html .= '</'.$openedtags[$i].'>';
    } else {
      unset($closedtags[array_search($openedtags[$i], $closedtags)]);    }
  }  return $html;
}  



function strpos_arr($haystack, $needle) {
    if(!is_array($needle)) $needle = array($needle);
    foreach($needle as $what) {
        if($haystack == $what) return true;
    }
    return false;
}
function formatBytes($b,$p = null) {
    $units = array("B","kB","MB","GB","TB","PB","EB","ZB","YB");
    $c=0;
    if(!$p && $p !== 0) {
        foreach($units as $k => $u) {
            if(($b / pow(1024,$k)) >= 1) {
                $r["bytes"] = $b / pow(1024,$k);
                $r["units"] = $u;
                $c++;
            }
        }
        return number_format($r["bytes"],2) . " " . $r["units"];
    } else {
        return number_format($b / pow(1024,$p)) . " " . $units[$p];
    }
}

function filterType($text) {
	switch ($text) {
		case 'list': return JText::_('List');
			break;
		case 'detail': return JText::_('Detail');
			break;
		default: return JText::_('Unknown');
			break;
	}
}

?>