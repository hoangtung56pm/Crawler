<?php
class gURL
{
    function newURI($base=false, $rel=false)
    {
        if ($base==false || $rel==false)
        {    
            printf("Error in %s line %d\n",__FILE__,__LINE__-3);
            return;
        }
        $pBase = parse_url($base);
        $pRel  = parse_url($rel);
        

        if ( isset($pRel['scheme']) )
        {
            /*
             *    The relative URL is not relative, so return it.
             */
            $ret = $rel;
        }
        else    
        {
            $ret  = $pBase['scheme']."://".$pBase['host'];
            $ret .= isset($pBase['port']) && $pBase['port']!=80 ? ":".$pBase['port']."/" : "/";
            if ($rel[0] == "/")
            {
                $ret .= substr($rel,1);
            }
            else 
            {
                $tmp = $this->Folder2Array($pBase['path']);
                $tmp1 = $this->Folder2Array($pRel['path'],false);
                
                foreach($tmp1 as $id1 => $d1)
                    if ($d1 == "..") unset($tmp[count($tmp)-1]);
                    else if ($d1 == ".") continue;
                    else $tmp[] = $d1;
                $ret .= implode("/",$tmp);
                $ret .= substr($rel,-1,1) == "/" ? "/" : "";
                $ret .= isset($pRel['query']) ? "?".$pRel['query'] : "";
                unset($tmp,$tmp1); /* Release memory */
            }
        }
        unset($pBase,$pRel);/* Release memory */
        return $ret;
    }    
    
    function Folder2Array($path,$onlyDir=true)
    {
        if ($path[0] == '/')
            $path=substr($path,1);
        $ret = explode("/",$path);
        if ( $onlyDir && substr(trim($path),-1,1) != "/")
            /*
             * If onlyDir is true and the last letter isn't a /
             * seems that is not a Dir! so, delete it!
             */
            unset( $ret[count($ret)-1] );
        
        if ($ret[count($ret)-1]=="")
            /*
             * If the last element of $ret is empty, delete it
             */
            unset($ret[count($ret)-1]);
        return $ret;
    }
}

	function split_url( $url, $decode=TRUE )
	{
		// Character sets from RFC3986.
		$xunressub     = 'a-zA-Z\d\-._~\!$&\'()*+,;=';
		$xpchar        = $xunressub . ':@%';

		// Scheme from RFC3986.
		$xscheme        = '([a-zA-Z][a-zA-Z\d+-.]*)';

		// User info (user + password) from RFC3986.
		$xuserinfo     = '((['  . $xunressub . '%]*)' .
						 '(:([' . $xunressub . ':%]*))?)';

		// IPv4 from RFC3986 (without digit constraints).
		$xipv4         = '(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})';

		// IPv6 from RFC2732 (without digit and grouping constraints).
		$xipv6         = '(\[([a-fA-F\d.:]+)\])';

		// Host name from RFC1035.  Technically, must start with a letter.
		// Relax that restriction to better parse URL structure, then
		// leave host name validation to application.
		$xhost_name    = '([a-zA-Z\d-.%]+)';

		// Authority from RFC3986.  Skip IP future.
		$xhost         = '(' . $xhost_name . '|' . $xipv4 . '|' . $xipv6 . ')';
		$xport         = '(\d*)';
		$xauthority    = '((' . $xuserinfo . '@)?' . $xhost .
					 '?(:' . $xport . ')?)';

		// Path from RFC3986.  Blend absolute & relative for efficiency.
		$xslash_seg    = '(/[' . $xpchar . ']*)';
		$xpath_authabs = '((//' . $xauthority . ')((/[' . $xpchar . ']*)*))';
		$xpath_rel     = '([' . $xpchar . ']+' . $xslash_seg . '*)';
		$xpath_abs     = '(/(' . $xpath_rel . ')?)';
		$xapath        = '(' . $xpath_authabs . '|' . $xpath_abs .
				 '|' . $xpath_rel . ')';

		// Query and fragment from RFC3986.
		$xqueryfrag    = '([' . $xpchar . '/?' . ']*)';

		// URL.
		$xurl          = '^(' . $xscheme . ':)?' .  $xapath . '?' .
						 '(\?' . $xqueryfrag . ')?(#' . $xqueryfrag . ')?$';


		// Split the URL into components.
		if ( !preg_match( '!' . $xurl . '!', $url, $m ) )
			return FALSE;

		if ( !empty($m[2]) )		$parts['scheme']  = strtolower($m[2]);

		if ( !empty($m[7]) ) {
			if ( isset( $m[9] ) )	$parts['user']    = $m[9];
			else			$parts['user']    = '';
		}
		if ( !empty($m[10]) )		$parts['pass']    = $m[11];

		if ( !empty($m[13]) )		$h=$parts['host'] = $m[13];
		else if ( !empty($m[14]) )	$parts['host']    = $m[14];
		else if ( !empty($m[16]) )	$parts['host']    = $m[16];
		else if ( !empty( $m[5] ) )	$parts['host']    = '';
		if ( !empty($m[17]) )		$parts['port']    = $m[18];

		if ( !empty($m[19]) )		$parts['path']    = $m[19];
		else if ( !empty($m[21]) )	$parts['path']    = $m[21];
		else if ( !empty($m[25]) )	$parts['path']    = $m[25];

		if ( !empty($m[27]) )		$parts['query']   = $m[28];
		if ( !empty($m[29]) )		$parts['fragment']= $m[30];

		if ( !$decode )
			return $parts;
		if ( !empty($parts['user']) )
			$parts['user']     = rawurldecode( $parts['user'] );
		if ( !empty($parts['pass']) )
			$parts['pass']     = rawurldecode( $parts['pass'] );
		if ( !empty($parts['path']) )
			$parts['path']     = rawurldecode( $parts['path'] );
		if ( isset($h) )
			$parts['host']     = rawurldecode( $parts['host'] );
		if ( !empty($parts['query']) )
			$parts['query']    = rawurldecode( $parts['query'] );
		if ( !empty($parts['fragment']) )
			$parts['fragment'] = rawurldecode( $parts['fragment'] );
		return $parts;
	}


function url_to_absolute( $baseUrl, $relativeUrl )
{
$url = new gUrl;
return $url->newUri($baseUrl,$relativeUrl);
}

function bulk_make_abs($content, $base)
{
return($content);
}
	
?>