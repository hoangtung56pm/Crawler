<?php


/**
/**
* @version		$Id: cron.php Nov 1, 2009
* @package		ecom
* @copyright	Copyright (C) 2007 - 2009 NhutCorp. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class NgrabnewsControllerUpgrade extends NgrabnewsController {
	function dostep() {
		$task = JRequest::getVar('task')?JRequest::getVar('task'):JRequest::getVar('layout', null, 'default', 'cmd');
		$this->execute($task);
	}
	function go(){
		global $mainframe;
		$database=JFactory::getDBO();
		$query = "ALTER TABLE
				`#__ngrab_cron` ADD `getimg_intro` TINYINT( 1 ) NOT NULL DEFAULT '1' AFTER `extract_img` ,
					ADD `getimg_detail` TINYINT( 1 ) NOT NULL DEFAULT '1' AFTER `getimg_intro` ,
					ADD `store_bydate` TINYINT( 1 ) NOT NULL DEFAULT '1' AFTER `getimg_detail`
				";
		$database->setQuery( $query );
		if (!$database->query()) {
			echo 'Database Error';
			exit();
		}
		$query = "CREATE TABLE IF NOT EXISTS `#__ngrab_imgs` (
				`id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
				`usage_id` INT( 11 ) NOT NULL DEFAULT '0',
				`img_path` VARCHAR( 255 ) NOT NULL DEFAULT '',
				`img_size` INT( 11 ) NOT NULL ,
				`cdate` DATETIME NOT NULL 
				) ENGINE = MYISAM;
				";
		$database->setQuery( $query );
		if (!$database->query()) {
			echo 'Database Error';
			exit();
		}
		echo 'Update database success';
		exit();
	}
}
?>
