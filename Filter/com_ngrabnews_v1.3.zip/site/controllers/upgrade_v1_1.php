<?php
/** beta to 1.1
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class NgrabnewsControllerUpgrade_v1_1 extends NgrabnewsController {
	function dostep() {
		$task = JRequest::getVar('task')?JRequest::getVar('task'):JRequest::getVar('layout', null, 'default', 'cmd');
		$this->execute($task);
	}
	function go(){
		global $mainframe;
		$database=JFactory::getDBO();
		$query = "ALTER TABLE
				`#__ngrab_imgs` ADD `ogi_path`  varchar(255) NOT NULL default '' AFTER `img_size` ,
					ADD `is_complete` tinyint(4) NOT NULL default '1'
				";
		$database->setQuery( $query );
		if (!$database->query()) {
			echo 'Database Error';
			exit();
		}
		echo 'Update database success';
		exit();
	}
}
?>
