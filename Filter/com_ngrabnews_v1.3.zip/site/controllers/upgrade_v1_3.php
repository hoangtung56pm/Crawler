<?php
/** 1.2 to 1.3
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class NgrabnewsControllerUpgrade_v1_3 extends NgrabnewsController {
	function dostep() {
		$task = JRequest::getVar('task')?JRequest::getVar('task'):JRequest::getVar('layout', null, 'default', 'cmd');
		$this->execute($task);
	}
	function go(){
		global $mainframe;
		$database=JFactory::getDBO();
		$query = "ALTER TABLE `#__ngrab_filter` ADD `filter_type` VARCHAR( 10 ) NULL AFTER `inc_bot` ,
				ADD `remote_num` INT( 11 ) NULL AFTER `filter_type` ,
				ADD `version_num` INT( 11 ) NULL AFTER `remote_num`";

		$database->setQuery( $query );
		if (!$database->query()) {
			echo 'Database Error';
			exit();
		}
		echo 'Update database success';
		exit();
	}
}
?>
